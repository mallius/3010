<?php
	// (C) Copyright 2001
	// Murray Jensen <Murray.Jensen@csiro.au>
	// CSIRO Manufacturing Science and Technology, Preston Lab

	// mysql database access info
	$mysql_user="fred";
	$mysql_pw="apassword";
	$mysql_db="mydbname";

	// where to put the eeprom config files
	$bddb_cfgdir = '/tftpboot/bddb';

	// what this database is called
	$bddb_label = 'Hymod Board Database';
?>
